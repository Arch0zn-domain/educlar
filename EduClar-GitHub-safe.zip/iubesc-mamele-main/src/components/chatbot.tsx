'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { ArrowUp, BookOpen, X } from 'lucide-react';

type Message = { role: 'user' | 'assistant'; content: string; cost?: number };
type Status = { balance?: number; error?: string };

function JellyProfessor({ small = false }: { small?: boolean }) {
  return <svg className={small ? 'jelly-professor jelly-small' : 'jelly-professor'} viewBox="0 0 100 100" role="img" aria-label="VNU Jelly, asistentul EduClar">
    <ellipse cx="50" cy="91" rx="34" ry="5" fill="#153f3020"/>
    <path d="M17 81c1-23 14-35 33-35s32 12 33 35c-8 8-58 8-66 0Z" fill="#236b52"/>
    <path d="m39 49 11 11 11-11 8 33H31l8-33Z" fill="#f8f8f2"/>
    <path d="m46 59 4 4 4-4 4 22H42l4-22Z" fill="#d49b3f"/>
    <path d="M19 45c0-21 12-33 31-33s31 12 31 33c0 20-13 31-31 31S19 65 19 45Z" fill="#f3cf5c" stroke="#d6ad39" strokeWidth="2"/>
    <ellipse cx="39" cy="43" rx="3" ry="4" fill="#263c35"/><ellipse cx="61" cy="43" rx="3" ry="4" fill="#263c35"/>
    <path d="M43 54q7 7 14 0" fill="none" stroke="#263c35" strokeWidth="2.5" strokeLinecap="round"/>
    <path d="m23 15 27-10 27 10-27 11-27-11Z" fill="#334d83" stroke="#263b6b" strokeWidth="2"/>
    <path d="M34 20v10c8 7 24 7 32 0V20l-16 7-16-7Z" fill="#405c96"/>
    <path d="M76 16v15" stroke="#d49b3f" strokeWidth="2.5"/><circle cx="76" cy="33" r="3" fill="#d49b3f"/>
  </svg>;
}

function estimate(text: string) {
  const value = text.trim();
  if (!value) return 25;
  if (value.length > 700 || (value.match(/[?;]/g) || []).length >= 4) return 100;
  if (value.length > 320 || /compar[aă]|analiz|plan|explic[aă].*(pas|detali)|mai multe/i.test(value)) return 75;
  if (value.length > 120 || /rezultat|statistic|profesor|liceu|școal[aă]|surs[aă]|medita/i.test(value)) return 50;
  return 25;
}

export function Chatbot({ signedIn }: { signedIn: boolean }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [balance, setBalance] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    fetch('/api/chat', { cache: 'no-store' }).then(async response => {
      const data = await response.json() as Status;
      if (response.ok) setBalance(data.balance ?? 5000);
      else setError(data.error || 'Nu am putut încărca soldul.');
    }).catch(() => setError('Nu am putut conecta chatul.'));
  }, [open, signedIn]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); }, [messages, busy]);

  async function send(event: FormEvent) {
    event.preventDefault();
    const text = input.trim();
    if (!text || busy || text.length > 1200) return;
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: messages.slice(-8), pathname: window.location.pathname }),
      });
      const data = await response.json() as Status & { answer?: string; charged?: number };
      if (!response.ok) {
        setBalance(data.balance ?? balance);
        setError(data.error || 'Mesajul nu a putut fi trimis.');
        return;
      }
      setMessages(current => [...current, { role: 'user', content: text, cost: data.charged }, { role: 'assistant', content: data.answer || 'Nu am primit un răspuns.' }]);
      setBalance(data.balance ?? null); setInput('');
    } catch { setError('Conexiunea a eșuat. Încearcă din nou.'); }
    finally { setBusy(false); }
  }

  return <>
    {!open && <button className="chat-launcher" onClick={() => setOpen(true)} aria-label="Deschide VNU Jelly"><JellyProfessor small/><span>Întreabă-l pe VNU Jelly</span><BookOpen size={16}/></button>}
    {open && <section className="chat-panel" aria-label="VNU Jelly, asistentul EduClar" aria-modal="false">
      <header className="chat-head"><JellyProfessor small/><div><strong>VNU Jelly · profesorul EduClar</strong><span>Asistentul site-ului · beta</span></div><button className="chat-close" aria-label="Închide chatul" onClick={() => setOpen(false)}><X size={19}/></button></header>
      <div className="chat-balance"><span>Sold</span><strong>{balance === null ? '…' : `${balance.toLocaleString('ro-RO')} puncte`}</strong><span> · mesaj: {estimate(input)} pct.</span></div>
      <div className="chat-messages" ref={scrollRef} aria-live="polite">
        {!messages.length && <div className="chat-welcome"><JellyProfessor/><strong>Bună! Eu sunt VNU Jelly.</strong><p>Te ajut să găsești școli, profesori, meditații și să înțelegi cum funcționează EduClar.</p><small>Răspunsurile folosesc informațiile site-ului. Nu trimite date personale. Mesajele nu se salvează în EduClar; textul este trimis către Google Gemini, care poate folosi datele din nivelul gratuit pentru îmbunătățirea serviciilor.</small>{!signedIn && <Link className="chat-signup" href="/autentificare">Creează cont și primești încă 4.000 de puncte</Link>}</div>}
        {messages.map((message, index) => <div className={`chat-bubble ${message.role}`} key={index}>{message.content}{message.cost !== undefined && <small className="chat-charge">−{message.cost} puncte</small>}</div>)}
        {busy && <div className="chat-bubble assistant typing">VNU Jelly se gândește…</div>}
      </div>
      {error && <p className="chat-error" role="alert">{error}</p>}
      {balance === 0 && !signedIn && <div className="chat-upsell">Ai folosit cele 1.000 de puncte gratuite. <Link href="/autentificare">Creează cont pentru restul de 4.000</Link></div>}
      <form className="chat-compose" onSubmit={send}><textarea value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key !== 'Enter' || event.shiftKey || event.nativeEvent.isComposing) return; event.preventDefault(); if (!busy && input.trim() && input.length <= 1200 && balance !== 0) event.currentTarget.form?.requestSubmit(); }} placeholder="Scrie o întrebare… (Enter trimite)" maxLength={1200} rows={2} disabled={busy || balance === 0} aria-label="Mesaj pentru Jelly"/><button type="submit" disabled={busy || !input.trim() || input.length > 1200 || balance === 0} aria-label="Trimite mesaj"><ArrowUp size={18}/></button><span>{input.length}/1200 · vizitator: 1.000 puncte; cont: până la 5.000 total · <Link href="/confidentialitate">Confidențialitate</Link></span></form>
    </section>}
  </>;
}
