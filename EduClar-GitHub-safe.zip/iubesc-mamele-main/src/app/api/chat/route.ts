import { currentUser } from '@/lib/auth';
import { query, serialized } from '@/lib/db';
import { catalog, teachers, totals } from '@/lib/read';
import { cookies } from 'next/headers';
import { createHash, randomBytes } from 'node:crypto';

const GUEST_POINTS = 1000;
const ACCOUNT_BONUS = 4000;
const MAX_MESSAGE_LENGTH = 1200;
const GUEST_COOKIE = 'educlar_chat_guest';
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';

function reply(body: object, status = 200) {
  return Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
}

async function identityAndWallet() {
  const user = await currentUser();
  const jar = await cookies();
  let guestToken = jar.get(GUEST_COOKIE)?.value;
  if (!guestToken || !/^[a-f0-9]{64}$/.test(guestToken)) {
    guestToken = randomBytes(32).toString('hex');
    jar.set(GUEST_COOKIE, guestToken, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 24 * 365 });
  }
  const guestHash = createHash('sha256').update(guestToken).digest('hex');
  const ownerKey = user ? `user:${user.id}` : `guest:${guestHash}`;
  const [wallet] = await serialized(async () => {
    if (user) {
      let existing = (await query<{ balance: number }>('SELECT balance FROM chat_wallets WHERE user_id=$1', [user.id]))[0];
      const guest = (await query<{ balance: number; guest_claimed: boolean }>('SELECT balance,guest_claimed FROM chat_wallets WHERE guest_hash=$1', [guestHash]))[0];
      if (existing) {
        if (guest && !guest.guest_claimed) {
          const combinedBalance = Math.max(0, existing.balance + guest.balance - GUEST_POINTS);
          await query('UPDATE chat_wallets SET balance=$2,updated_at=now() WHERE user_id=$1', [user.id, combinedBalance]);
          await query('UPDATE chat_wallets SET balance=0,guest_claimed=true,guest_claimed_by=$2,updated_at=now() WHERE guest_hash=$1 AND NOT guest_claimed', [guestHash, user.id]);
          existing = { balance: combinedBalance };
        }
        return [existing];
      }
      let balance = 5000;
      if (guest) {
        if (!guest.guest_claimed) {
          balance = Math.min(5000, ACCOUNT_BONUS + guest.balance);
          await query('UPDATE chat_wallets SET balance=0,guest_claimed=true,guest_claimed_by=$2,updated_at=now() WHERE guest_hash=$1 AND NOT guest_claimed', [guestHash, user.id]);
        } else {
          balance = 0;
        }
      }
      await query('INSERT INTO chat_wallets(owner_key,user_id,balance) VALUES($1,$2,$3) ON CONFLICT(user_id) DO NOTHING', [ownerKey, user.id, balance]);
      existing = (await query<{ balance: number }>('SELECT balance FROM chat_wallets WHERE user_id=$1', [user.id]))[0];
      return [existing];
    }
    await query('INSERT INTO chat_wallets(owner_key,guest_hash,balance) VALUES($1,$2,$3) ON CONFLICT(owner_key) DO NOTHING', [ownerKey, guestHash, GUEST_POINTS]);
    return query<{ balance: number }>('SELECT balance FROM chat_wallets WHERE owner_key=$1', [ownerKey]);
  });
  return { user, ownerKey, balance: wallet.balance };
}

export async function GET() {
  const identity = await identityAndWallet();
  return reply({ balance: identity.balance, hasAccount: Boolean(identity.user) });
}

function chargeFor(message: string) {
  if (message.length > 700 || (message.match(/[?;]/g) || []).length >= 4) return 100;
  if (message.length > 320 || /compar[aă]|analiz|plan|explic[aă].*(pas|detali)|mai multe/i.test(message)) return 75;
  if (message.length > 120 || /rezultat|statistic|profesor|liceu|școal[aă]|surs[aă]|medita/i.test(message)) return 50;
  return 25;
}

const pageDescriptions: Record<string, string> = {
  '/': 'Pagina principală prezintă căutarea și traseele principale.',
  '/scoli': 'Catalogul permite căutarea și filtrarea școlilor după localitate, județ, tip, examen și an; se pot compara până la trei școli.',
  '/profesori': 'Catalogul profesorilor permite căutarea după nume, materie și școală. Recenziile sunt moderate și agregatele apar numai când există suficiente recenzii aprobate.',
  '/meditatii': 'Pagina listează ofertele profesorilor; solicitările și datele de contact urmează fluxul din cont, iar utilizatorii minori au nevoie de tutela prevăzută de site.',
  '/absolventi': 'Pagina afișează povești publicate de absolvenți adulți; publicarea este aleasă de autor.',
  '/compara': 'Pagina compară școlile selectate din catalog.',
  '/date': 'Pagina descrie sursele, acoperirea și limitele datelor.',
  '/metodologie': 'Pagina explică metodologia și proveniența datelor.',
  '/cont': 'Contul include cereri de meditații, recenzii, verificări, tutelă, oferte eligibile, profilul de absolvent și solicitări de date.',
  '/autentificare': 'Autentificarea prototipului folosește coduri demonstrative, nu SMS-uri reale.',
};

const stopwords = new Set('care unde cum ce cine când pentru despre este sunt sunteti poti pot poate vreau vreti site educlar acest aceasta toate cumva unui unei din prin către cat mai multe date informații informatii profesor profesorul scoala școală liceu romania'.split(' '));

async function siteContext(message: string, pathname: string) {
  const counts = await totals();
  const page = pageDescriptions[pathname] || 'Pagina curentă aparține site-ului EduClar.';
  const terms = [...new Set(message.toLocaleLowerCase('ro').replace(/[^\p{L}\p{N} -]/gu, ' ').split(/\s+/).filter(word => word.length >= 4 && !stopwords.has(word)))].slice(0, 3);
  const isSchoolQuestion = /școl|scol|liceu|colegi|institu|bac|evaluare/i.test(message);
  const isTeacherQuestion = /profesor|medita|tutore|cadru didactic/i.test(message);
  const live: string[] = [];
  if (isSchoolQuestion) {
    const found = new Map<string, any>();
    for (const term of terms.slice(0, 2)) {
      const results = await catalog({ q: term });
      for (const school of results.schools.slice(0, 3)) found.set(school.id, school);
    }
    for (const school of [...found.values()].slice(0, 5)) live.push(`Școală din catalog: ${school.name}; ${school.city}, ${school.county}; tip: ${school.type}; demo: ${school.demo ? 'da' : 'nu'}; ${school.source_title ? `sursă: ${school.source_title}` : ''}${school.average != null ? `; medie publică: ${school.average}/10 (${school.stat_exam || 'examen'} ${school.stat_year || ''})` : ''}.`);
  }
  if (isTeacherQuestion) {
    const found = new Map<string, any>();
    for (const term of terms.slice(0, 2)) for (const teacher of (await teachers({ q: term })).slice(0, 3)) found.set(teacher.id, teacher);
    for (const teacher of [...found.values()].slice(0, 5)) live.push(`Profesor în catalog: ${teacher.name}; materii: ${teacher.subjects.join(', ')}; demo: ${teacher.demo ? 'da' : 'nu'}; profil: /profesori/${teacher.id}.`);
  }
  return `EduClar este un prototip în limba română pentru explorarea școlilor și rezultatelor agregate, compararea școlilor, descoperirea profesorilor, recenzii moderate, oferte și cereri de meditații, profiluri de absolvenți și informare despre surse. Linkuri utile: /scoli, /profesori, /meditatii, /absolventi, /compara, /date, /metodologie, /cont, /termeni, /confidentialitate. Catalogul are acum aproximativ ${counts.schools} școli (dintre care ${counts.official} marcate oficial) și ${counts.teachers} profiluri de profesori; verifică pagina /date pentru acoperirea curentă. Datele demo sunt fictive; statisticile sunt istorice/agregate și fiecare fișă indică sursa disponibilă. Site-ul nu oferă decizii educaționale garantate. Asistentul poate explica și orienta, dar nu poate trimite recenzii, crea conturi, face rezervări sau modifica date. Pagina vizitată de utilizator: ${page}${live.length ? `\n\nRezultate potrivite găsite acum în catalog:\n${live.join('\n')}` : ''}`;
}

export async function POST(request: Request) {
  const origin = request.headers.get('origin');
  if (!origin || new URL(origin).host !== request.headers.get('host')) return reply({ error: 'Cerere nevalidă.' }, 403);
  if (Number(request.headers.get('content-length') || 0) > 16000) return reply({ error: 'Mesajul este prea mare.' }, 413);
  if (!process.env.GEMINI_API_KEY) return reply({ error: 'VNU Jelly nu este configurat încă. Administratorul trebuie să adauge cheia gratuită Gemini API.' }, 503);

  let body: any;
  try { body = await request.json(); } catch { return reply({ error: 'Cerere nevalidă.' }, 400); }
  const message = typeof body.message === 'string' ? body.message.trim() : '';
  if (!message || message.length > MAX_MESSAGE_LENGTH) return reply({ error: 'Scrie un mesaj de maximum 1.200 de caractere.' }, 400);
  const history = Array.isArray(body.history) ? body.history.slice(-8).filter((entry: any) => entry && ['user', 'assistant'].includes(entry.role) && typeof entry.content === 'string' && entry.content.length <= MAX_MESSAGE_LENGTH).map((entry: any) => ({ role: entry.role, content: entry.content })) : [];
  const cost = chargeFor(message);
  const identity = await identityAndWallet();

  const reserved = await serialized(async () => {
    const rate = (await query<{ count: number }>("INSERT INTO rate_limits(key,count,expires_at) VALUES($1,1,now()+interval '1 day') ON CONFLICT(key) DO UPDATE SET count=CASE WHEN rate_limits.expires_at<now() THEN 1 ELSE rate_limits.count+1 END, expires_at=CASE WHEN rate_limits.expires_at<now() THEN now()+interval '1 day' ELSE rate_limits.expires_at END RETURNING count", [`chat:${identity.ownerKey}`]))[0];
    if (rate.count > 20) return { limited: true as const };
    const wallet = (await query<{ balance: number }>('UPDATE chat_wallets SET balance=balance-$2,updated_at=now() WHERE owner_key=$1 AND balance >= $2 RETURNING balance', [identity.ownerKey, cost]))[0];
    return wallet ? { ok: true as const, balance: wallet.balance } : { ok: false as const, balance: (await query<{ balance: number }>('SELECT balance FROM chat_wallets WHERE owner_key=$1', [identity.ownerKey]))[0].balance };
  });
  if ('limited' in reserved) return reply({ error: 'Ai ajuns la limita de 20 de mesaje pe zi. Încearcă mâine.' }, 429);
  if (!reserved.ok) return reply({ error: 'Nu mai ai suficiente puncte pentru acest mesaj.', balance: reserved.balance }, 402);
  const charged = reserved.balance;

  try {
    const context = await siteContext(message, typeof body.pathname === 'string' ? body.pathname.slice(0, 120) : '/');
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: 'POST', signal: AbortSignal.timeout(45000),
      headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: `Ești VNU Jelly, asistentul prietenos al EduClar. Vorbești în română, natural, clar și concis. La saluturi și conversație simplă răspunzi firesc și scurt; de exemplu, la „Salut!” poți spune „Salut! Cu ce te pot ajuta?”. Nu repeta descrierea site-ului, recomandări generale de siguranță sau avertismente nesolicitate; menționează o limită doar când este relevantă pentru întrebare. Răspunzi despre site folosind informațiile de mai jos. Dacă o informație lipsește, spune simplu că nu o poți confirma și indică pagina relevantă. Nu inventa rezultate, persoane, surse, costuri sau funcții. Marchează datele demo ca fictive și statisticile ca istorice/agregate. Nu pretinde că poți executa acțiuni pe site. Nu cere și nu divulga datele private ale altor utilizatori.\n\n${context}` }] },
        contents: [...history, { role: 'user', content: message }].map(entry => ({ role: entry.role === 'assistant' ? 'model' : 'user', parts: [{ text: entry.content }] })),
        generationConfig: { maxOutputTokens: 700 },
      }),
    });
    const data = await response.json() as { candidates?: { content?: { parts?: { text?: string }[] } }[]; error?: { message?: string } };
    if (!response.ok) throw new Error(`Gemini API ${response.status}: ${data.error?.message || ''}`);
    const answer = (data.candidates?.[0]?.content?.parts || []).map(item => item.text || '').join('\n').trim();
    if (!answer) throw new Error('Gemini a returnat un răspuns gol.');
    return reply({ answer, charged: cost, balance: charged });
  } catch (error) {
    await serialized(async () => { await query('UPDATE chat_wallets SET balance=LEAST(5000,balance+$2),updated_at=now() WHERE owner_key=$1', [identity.ownerKey, cost]); });
    console.error('EduClar chatbot request failed:', error);
    const balance = (await query<{ balance: number }>('SELECT balance FROM chat_wallets WHERE owner_key=$1', [identity.ownerKey]))[0].balance;
    const detail = error instanceof Error ? error.message : '';
    const message = detail.includes('Gemini API 401')
      ? 'Cheia Gemini configurată nu este acceptată. Creează o cheie nouă în Google AI Studio și înlocuiește valoarea GEMINI_API_KEY din .env.local; nu trimite cheia în chat. Nu ți s-au dedus puncte.'
      : detail.includes('Gemini API 403')
        ? 'Cheia Gemini nu are acces la acest API sau proiect. Verifică setările cheii în Google AI Studio. Nu ți s-au dedus puncte.'
        : detail.includes('Gemini API 429')
          ? 'Gemini a atins momentan limita de utilizare. Încearcă din nou după resetarea cotei. Nu ți s-au dedus puncte.'
          : 'Jelly nu a putut răspunde acum. Nu ți s-au dedus puncte. Încearcă din nou.';
    return reply({ error: message, balance }, 502);
  }
}
