import { auth } from '@/lib/auth';
export const runtime = 'nodejs';
export async function POST(request: Request) { return (await auth()).handler(request); }
