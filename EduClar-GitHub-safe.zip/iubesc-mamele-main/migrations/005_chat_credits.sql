CREATE TABLE IF NOT EXISTS chat_credits (
  user_id text PRIMARY KEY REFERENCES auth_user(id) ON DELETE CASCADE,
  balance integer NOT NULL DEFAULT 5000 CHECK (balance >= 0 AND balance <= 5000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
