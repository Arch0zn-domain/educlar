CREATE TABLE IF NOT EXISTS chat_wallets (
  owner_key text PRIMARY KEY,
  user_id text UNIQUE REFERENCES auth_user(id) ON DELETE CASCADE,
  guest_hash text UNIQUE,
  guest_claimed boolean NOT NULL DEFAULT false,
  guest_claimed_by text REFERENCES auth_user(id) ON DELETE SET NULL,
  balance integer NOT NULL CHECK (balance >= 0 AND balance <= 5000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((user_id IS NOT NULL) <> (guest_hash IS NOT NULL))
);

INSERT INTO chat_wallets(owner_key,user_id,balance)
SELECT 'user:' || user_id,user_id,balance FROM chat_credits
ON CONFLICT (user_id) DO NOTHING;
